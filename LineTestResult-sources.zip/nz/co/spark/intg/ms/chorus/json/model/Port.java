
package nz.co.spark.intg.ms.chorus.json.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "lineId",
    "rspName"
})
public class Port {

    @JsonProperty("lineId")
    private String lineId;
    @JsonProperty("rspName")
    private String rspName;

    @JsonProperty("lineId")
    public String getLineId() {
        return lineId;
    }

    @JsonProperty("lineId")
    public void setLineId(String lineId) {
        this.lineId = lineId;
    }

    @JsonProperty("rspName")
    public String getRspName() {
        return rspName;
    }

    @JsonProperty("rspName")
    public void setRspName(String rspName) {
        this.rspName = rspName;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("lineId", lineId).append("rspName", rspName).toString();
    }

}
