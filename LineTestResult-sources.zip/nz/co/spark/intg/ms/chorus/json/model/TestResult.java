
package nz.co.spark.intg.ms.chorus.json.model;

import java.util.List;
import javax.validation.Valid;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "impedanceTestFrequency",
    "impedanceTestVoltage",
    "estimatedLoopLength",
    "loopTermination",
    "detectedProblems",
    "errorDetails"
})
public class TestResult {

    @JsonProperty("impedanceTestFrequency")
    private String impedanceTestFrequency;
    @JsonProperty("impedanceTestVoltage")
    private String impedanceTestVoltage;
    @JsonProperty("estimatedLoopLength")
    private String estimatedLoopLength;
    @JsonProperty("loopTermination")
    private String loopTermination;
    @JsonProperty("detectedProblems")
    @Valid
    private List<DetectedProblem> detectedProblems = null;
    @JsonProperty("errorDetails")
    @Valid
    private List<Object> errorDetails = null;

    @JsonProperty("impedanceTestFrequency")
    public String getImpedanceTestFrequency() {
        return impedanceTestFrequency;
    }

    @JsonProperty("impedanceTestFrequency")
    public void setImpedanceTestFrequency(String impedanceTestFrequency) {
        this.impedanceTestFrequency = impedanceTestFrequency;
    }

    @JsonProperty("impedanceTestVoltage")
    public String getImpedanceTestVoltage() {
        return impedanceTestVoltage;
    }

    @JsonProperty("impedanceTestVoltage")
    public void setImpedanceTestVoltage(String impedanceTestVoltage) {
        this.impedanceTestVoltage = impedanceTestVoltage;
    }

    @JsonProperty("estimatedLoopLength")
    public String getEstimatedLoopLength() {
        return estimatedLoopLength;
    }

    @JsonProperty("estimatedLoopLength")
    public void setEstimatedLoopLength(String estimatedLoopLength) {
        this.estimatedLoopLength = estimatedLoopLength;
    }

    @JsonProperty("loopTermination")
    public String getLoopTermination() {
        return loopTermination;
    }

    @JsonProperty("loopTermination")
    public void setLoopTermination(String loopTermination) {
        this.loopTermination = loopTermination;
    }

    @JsonProperty("detectedProblems")
    public List<DetectedProblem> getDetectedProblems() {
        return detectedProblems;
    }

    @JsonProperty("detectedProblems")
    public void setDetectedProblems(List<DetectedProblem> detectedProblems) {
        this.detectedProblems = detectedProblems;
    }

    @JsonProperty("errorDetails")
    public List<Object> getErrorDetails() {
        return errorDetails;
    }

    @JsonProperty("errorDetails")
    public void setErrorDetails(List<Object> errorDetails) {
        this.errorDetails = errorDetails;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("impedanceTestFrequency", impedanceTestFrequency).append("impedanceTestVoltage", impedanceTestVoltage).append("estimatedLoopLength", estimatedLoopLength).append("loopTermination", loopTermination).append("detectedProblems", detectedProblems).append("errorDetails", errorDetails).toString();
    }

}
