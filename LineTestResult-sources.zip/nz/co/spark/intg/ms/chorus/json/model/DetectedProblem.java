
package nz.co.spark.intg.ms.chorus.json.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "estimatedDistanceFromDslam",
    "problemDescription",
    "repairAdvice"
})
public class DetectedProblem {

    @JsonProperty("estimatedDistanceFromDslam")
    private String estimatedDistanceFromDslam;
    @JsonProperty("problemDescription")
    private String problemDescription;
    @JsonProperty("repairAdvice")
    private String repairAdvice;

    @JsonProperty("estimatedDistanceFromDslam")
    public String getEstimatedDistanceFromDslam() {
        return estimatedDistanceFromDslam;
    }

    @JsonProperty("estimatedDistanceFromDslam")
    public void setEstimatedDistanceFromDslam(String estimatedDistanceFromDslam) {
        this.estimatedDistanceFromDslam = estimatedDistanceFromDslam;
    }

    @JsonProperty("problemDescription")
    public String getProblemDescription() {
        return problemDescription;
    }

    @JsonProperty("problemDescription")
    public void setProblemDescription(String problemDescription) {
        this.problemDescription = problemDescription;
    }

    @JsonProperty("repairAdvice")
    public String getRepairAdvice() {
        return repairAdvice;
    }

    @JsonProperty("repairAdvice")
    public void setRepairAdvice(String repairAdvice) {
        this.repairAdvice = repairAdvice;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("estimatedDistanceFromDslam", estimatedDistanceFromDslam).append("problemDescription", problemDescription).append("repairAdvice", repairAdvice).toString();
    }

}
