
package nz.co.spark.intg.ms.chorus.json.model;

import java.util.List;
import javax.validation.Valid;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "success",
    "technicalFaultPresent",
    "businessError"
})
public class BusinessResult {

    @JsonProperty("success")
    private String success;
    @JsonProperty("technicalFaultPresent")
    private String technicalFaultPresent;
    @JsonProperty("businessError")
    @Valid
    private List<Object> businessError = null;

    @JsonProperty("success")
    public String getSuccess() {
        return success;
    }

    @JsonProperty("success")
    public void setSuccess(String success) {
        this.success = success;
    }

    @JsonProperty("technicalFaultPresent")
    public String getTechnicalFaultPresent() {
        return technicalFaultPresent;
    }

    @JsonProperty("technicalFaultPresent")
    public void setTechnicalFaultPresent(String technicalFaultPresent) {
        this.technicalFaultPresent = technicalFaultPresent;
    }

    @JsonProperty("businessError")
    public List<Object> getBusinessError() {
        return businessError;
    }

    @JsonProperty("businessError")
    public void setBusinessError(List<Object> businessError) {
        this.businessError = businessError;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("success", success).append("technicalFaultPresent", technicalFaultPresent).append("businessError", businessError).toString();
    }

}
