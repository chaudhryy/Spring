
package nz.co.spark.intg.ms.chorus.json.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "validForStartTime",
    "validForEndTime",
    "status"
})
public class Resourcestatus {

    @JsonProperty("validForStartTime")
    private String validForStartTime;
    @JsonProperty("validForEndTime")
    private String validForEndTime;
    @JsonProperty("status")
    private String status;

    @JsonProperty("validForStartTime")
    public String getValidForStartTime() {
        return validForStartTime;
    }

    @JsonProperty("validForStartTime")
    public void setValidForStartTime(String validForStartTime) {
        this.validForStartTime = validForStartTime;
    }

    @JsonProperty("validForEndTime")
    public String getValidForEndTime() {
        return validForEndTime;
    }

    @JsonProperty("validForEndTime")
    public void setValidForEndTime(String validForEndTime) {
        this.validForEndTime = validForEndTime;
    }

    @JsonProperty("status")
    public String getStatus() {
        return status;
    }

    @JsonProperty("status")
    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("validForStartTime", validForStartTime).append("validForEndTime", validForEndTime).append("status", status).toString();
    }

}
