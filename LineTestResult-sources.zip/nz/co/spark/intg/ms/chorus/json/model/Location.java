
package nz.co.spark.intg.ms.chorus.json.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "addressLine1",
    "streetNrFirst",
    "streetName",
    "locality",
    "townOrCity",
    "postcode"
})
public class Location {

    @JsonProperty("addressLine1")
    private String addressLine1;
    @JsonProperty("streetNrFirst")
    private String streetNrFirst;
    @JsonProperty("streetName")
    private String streetName;
    @JsonProperty("locality")
    private String locality;
    @JsonProperty("townOrCity")
    private String townOrCity;
    @JsonProperty("postcode")
    private String postcode;

    @JsonProperty("addressLine1")
    public String getAddressLine1() {
        return addressLine1;
    }

    @JsonProperty("addressLine1")
    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    @JsonProperty("streetNrFirst")
    public String getStreetNrFirst() {
        return streetNrFirst;
    }

    @JsonProperty("streetNrFirst")
    public void setStreetNrFirst(String streetNrFirst) {
        this.streetNrFirst = streetNrFirst;
    }

    @JsonProperty("streetName")
    public String getStreetName() {
        return streetName;
    }

    @JsonProperty("streetName")
    public void setStreetName(String streetName) {
        this.streetName = streetName;
    }

    @JsonProperty("locality")
    public String getLocality() {
        return locality;
    }

    @JsonProperty("locality")
    public void setLocality(String locality) {
        this.locality = locality;
    }

    @JsonProperty("townOrCity")
    public String getTownOrCity() {
        return townOrCity;
    }

    @JsonProperty("townOrCity")
    public void setTownOrCity(String townOrCity) {
        this.townOrCity = townOrCity;
    }

    @JsonProperty("postcode")
    public String getPostcode() {
        return postcode;
    }

    @JsonProperty("postcode")
    public void setPostcode(String postcode) {
        this.postcode = postcode;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("addressLine1", addressLine1).append("streetNrFirst", streetNrFirst).append("streetName", streetName).append("locality", locality).append("townOrCity", townOrCity).append("postcode", postcode).toString();
    }

}
