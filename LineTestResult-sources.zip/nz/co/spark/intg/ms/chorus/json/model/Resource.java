
package nz.co.spark.intg.ms.chorus.json.model;

import java.util.List;
import javax.validation.Valid;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "resourceType",
    "resourceStatus",
    "product",
    "resourceCharacteristics",
    "testResult"
})
public class Resource {

    @JsonProperty("resourceType")
    private String resourceType;
    @JsonProperty("resourceStatus")
    @Valid
    private List<Resourcestatus> resourceStatus = null;
    @JsonProperty("product")
    @Valid
    private Product product;
    @JsonProperty("resourceCharacteristics")
    @Valid
    private List<ResourceCharacteristic> resourceCharacteristics = null;
    @JsonProperty("testResult")
    @Valid
    private TestResult testResult;

    @JsonProperty("resourceType")
    public String getResourceType() {
        return resourceType;
    }

    @JsonProperty("resourceType")
    public void setResourceType(String resourceType) {
        this.resourceType = resourceType;
    }

    @JsonProperty("resourceStatus")
    public List<Resourcestatus> getResourceStatus() {
        return resourceStatus;
    }

    @JsonProperty("resourceStatus")
    public void setResourceStatus(List<Resourcestatus> resourceStatus) {
        this.resourceStatus = resourceStatus;
    }

    @JsonProperty("product")
    public Product getProduct() {
        return product;
    }

    @JsonProperty("product")
    public void setProduct(Product product) {
        this.product = product;
    }

    @JsonProperty("resourceCharacteristics")
    public List<ResourceCharacteristic> getResourceCharacteristics() {
        return resourceCharacteristics;
    }

    @JsonProperty("resourceCharacteristics")
    public void setResourceCharacteristics(List<ResourceCharacteristic> resourceCharacteristics) {
        this.resourceCharacteristics = resourceCharacteristics;
    }

    @JsonProperty("testResult")
    public TestResult getTestResult() {
        return testResult;
    }

    @JsonProperty("testResult")
    public void setTestResult(TestResult testResult) {
        this.testResult = testResult;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("resourceType", resourceType).append("resourceStatus", resourceStatus).append("product", product).append("resourceCharacteristics", resourceCharacteristics).append("testResult", testResult).toString();
    }

}
