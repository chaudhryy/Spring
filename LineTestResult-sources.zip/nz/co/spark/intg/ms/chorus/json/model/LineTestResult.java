
package nz.co.spark.intg.ms.chorus.json.model;

import javax.validation.Valid;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "businessResult",
    "resource"
})
public class LineTestResult {

    @JsonProperty("businessResult")
    @Valid
    private BusinessResult businessResult;
    @JsonProperty("resource")
    @Valid
    private Resource resource;

    @JsonProperty("businessResult")
    public BusinessResult getBusinessResult() {
        return businessResult;
    }

    @JsonProperty("businessResult")
    public void setBusinessResult(BusinessResult businessResult) {
        this.businessResult = businessResult;
    }

    @JsonProperty("resource")
    public Resource getResource() {
        return resource;
    }

    @JsonProperty("resource")
    public void setResource(Resource resource) {
        this.resource = resource;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("businessResult", businessResult).append("resource", resource).toString();
    }

}
