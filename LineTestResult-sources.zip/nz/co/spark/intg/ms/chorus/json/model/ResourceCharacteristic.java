
package nz.co.spark.intg.ms.chorus.json.model;

import java.util.List;
import javax.validation.Valid;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "resourceCharacteristicValue",
    "type"
})
public class ResourceCharacteristic {

    @JsonProperty("resourceCharacteristicValue")
    @Valid
    private List<ResourceCharacteristicValue> resourceCharacteristicValue = null;
    @JsonProperty("type")
    private String type;

    @JsonProperty("resourceCharacteristicValue")
    public List<ResourceCharacteristicValue> getResourceCharacteristicValue() {
        return resourceCharacteristicValue;
    }

    @JsonProperty("resourceCharacteristicValue")
    public void setResourceCharacteristicValue(List<ResourceCharacteristicValue> resourceCharacteristicValue) {
        this.resourceCharacteristicValue = resourceCharacteristicValue;
    }

    @JsonProperty("type")
    public String getType() {
        return type;
    }

    @JsonProperty("type")
    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("resourceCharacteristicValue", resourceCharacteristicValue).append("type", type).toString();
    }

}
