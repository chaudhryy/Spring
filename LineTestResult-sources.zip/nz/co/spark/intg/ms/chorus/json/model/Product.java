
package nz.co.spark.intg.ms.chorus.json.model;

import javax.validation.Valid;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "productId",
    "productType",
    "location",
    "port"
})
public class Product {

    @JsonProperty("productId")
    private String productId;
    @JsonProperty("productType")
    private String productType;
    @JsonProperty("location")
    @Valid
    private Location location;
    @JsonProperty("port")
    @Valid
    private Port port;

    @JsonProperty("productId")
    public String getProductId() {
        return productId;
    }

    @JsonProperty("productId")
    public void setProductId(String productId) {
        this.productId = productId;
    }

    @JsonProperty("productType")
    public String getProductType() {
        return productType;
    }

    @JsonProperty("productType")
    public void setProductType(String productType) {
        this.productType = productType;
    }

    @JsonProperty("location")
    public Location getLocation() {
        return location;
    }

    @JsonProperty("location")
    public void setLocation(Location location) {
        this.location = location;
    }

    @JsonProperty("port")
    public Port getPort() {
        return port;
    }

    @JsonProperty("port")
    public void setPort(Port port) {
        this.port = port;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("productId", productId).append("productType", productType).append("location", location).append("port", port).toString();
    }

}
