package com.yash.service;

import com.yash.beans.RestOcpClient;
import com.yash.cache.LocalCache;
import com.yash.exceptions.OcpException;
import com.yash.ocp.db.service.ModuleRouteInfoService;
import com.yash.provider.ocp.json.routelist.RouteListSuccessResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

@Component
public class ApicRestService {

    @Autowired
    ModuleRouteInfoService moduleRouteInfoService;

    @Autowired
    RestOcpClient client;

    @Autowired
    LocalCache cache;

    public void execute(String ... args ) throws OcpException {

        cache.setAuthorization("LssMBgB94_hYw70sJTqrhli7xbioFtZCw9UNnkyYAms");
        cache.setNamespace("intg-int04");
        ResponseEntity<RouteListSuccessResponse> response = client.getRouteList();
        System.out.println(response.getStatusCode());
        System.out.println(response.getBody());
        moduleRouteInfoService.transformSwagger("test",response.getBody());
    }
}
