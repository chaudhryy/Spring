
package com.yash.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "fuse-endpoint"
})
public class Properties_ {

    @JsonProperty("fuse-endpoint")
    private String fuseEndpoint;

    @JsonProperty("fuse-endpoint")
    public String getFuseEndpoint() {
        return fuseEndpoint;
    }

    @JsonProperty("fuse-endpoint")
    public void setFuseEndpoint(String fuseEndpoint) {
        this.fuseEndpoint = fuseEndpoint;
    }

    public Properties_ withFuseEndpoint(String fuseEndpoint) {
        this.fuseEndpoint = fuseEndpoint;
        return this;
    }

}
