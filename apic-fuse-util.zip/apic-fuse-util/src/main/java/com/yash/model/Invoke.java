
package com.yash.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "target-url"
})
public class Invoke {

    @JsonProperty("target-url")
    private String targetUrl;

    @JsonProperty("target-url")
    public String getTargetUrl() {
        return targetUrl;
    }

    @JsonProperty("target-url")
    public void setTargetUrl(String targetUrl) {
        this.targetUrl = targetUrl;
    }

    public Invoke withTargetUrl(String targetUrl) {
        this.targetUrl = targetUrl;
        return this;
    }

}
