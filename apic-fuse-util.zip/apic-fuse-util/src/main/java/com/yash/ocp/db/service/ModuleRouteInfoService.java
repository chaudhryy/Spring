package com.yash.ocp.db.service;

import com.yash.beans.RestOcpClient;
import com.yash.cache.LocalCache;
import com.yash.exceptions.OcpException;
import com.yash.model.Properties;
import com.yash.model.*;
import com.yash.ocp.db.dao.ModuleRouteInfoDao;
import com.yash.provider.ocp.json.routelist.Item;
import com.yash.provider.ocp.json.routelist.RouteListSuccessResponse;
import io.swagger.models.*;
import io.swagger.models.auth.ApiKeyAuthDefinition;
import io.swagger.models.auth.In;
import io.swagger.models.auth.SecuritySchemeDefinition;
import io.swagger.parser.Swagger20Parser;
import io.swagger.util.Yaml;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.io.DataOutput;
import java.io.File;
import java.io.IOException;
import java.util.*;

//import com.yash.cache.PodCache;
//import com.yash.ocp.utils.OcpUtil;

@Service
public class ModuleRouteInfoService {

    @PersistenceContext
    EntityManager entityManager;

    @Autowired
    ModuleRouteInfoDao dao;

    @Autowired
    LocalCache cache;

//    @Autowired
//    PodCache podCache;


    @Autowired
    RestOcpClient client;


//    public void createInfo(RouteListSuccessResponse routeListSuccessResponse) {
//        int count = new Long(dao.count()).intValue();
//        if(routeListSuccessResponse != null && !CollectionUtils.isEmpty(routeListSuccessResponse.getItems())){
//            for(Item item : routeListSuccessResponse.getItems()){
//
//                if(item != null && item.getMetadata() != null && item.getMetadata().getName() != null ){
//                    if(item.getMetadata().getName().contains("rest")){
//                      count++;
//                        ModuleRouteInfo routeInfo = new ModuleRouteInfo();
//                        routeInfo.setId(count);
//                        routeInfo.setVersion(cache.getLastVersion());
//                        routeInfo.setModule_Name(item.getMetadata().getLabels().getApp());
//                        if (item.getMetadata().getAnnotations() != null && item.getMetadata().getAnnotations().getHaproxyRouterOpenshiftIoTimeout() != null) {
//                            routeInfo.setHaProxyTimeout(item.getMetadata().getAnnotations().getHaproxyRouterOpenshiftIoTimeout());
//                        }
//                        routeInfo.setPort(item.getSpec().getPort().getTargetPort());
//                        routeInfo.setHost(item.getSpec().getHost());
//                        routeInfo.setType("REST");
////                        routeInfo.setUrl();
//
//                        getAndSetDetailsFromSwagger(item.getSpec().getHost(),routeInfo);
//
//                        dao.save(routeInfo);
//
//                    }else if(!item.getMetadata().getName().startsWith("amq")){
//                        count++;
//                        ModuleRouteInfo routeInfo = new ModuleRouteInfo();
//                        routeInfo.setId(count);
//                        routeInfo.setVersion(cache.getLastVersion());
//                        routeInfo.setModule_Name(item.getMetadata().getLabels().getApp());
//                        if (item.getMetadata().getAnnotations() != null && item.getMetadata().getAnnotations().getHaproxyRouterOpenshiftIoTimeout() != null) {
//                            routeInfo.setHaProxyTimeout(item.getMetadata().getAnnotations().getHaproxyRouterOpenshiftIoTimeout());
//                        }
//                        routeInfo.setPort(item.getSpec().getPort().getTargetPort());
//                        routeInfo.setHost(item.getSpec().getHost());
//                        routeInfo.setType("SOAP");
//                        getAndSetDetailsFromCXFServiceList(item.getSpec().getHost(),routeInfo);
//
//                        dao.save(routeInfo);
//                        System.out.println("Successfully processed route dump for " + routeInfo.getHost() + " ,Version " + cache.getLastVersion());
//                    }
//                }
//            }
//        }
//
//    }
//
//    private void getAndSetDetailsFromCXFServiceList(String host, ModuleRouteInfo routeInfo) {
//        try {
//            String responseResponseEntity = client.getCxfServiceList(host);
//
//            if (responseResponseEntity != null && !responseResponseEntity.contains("Fetch-Exception")) {
//                List<String> keyList = new LinkedList<>();
//                List<String> valueList = new LinkedList<>();
//
//                {
//                    Pattern pattern = Pattern.compile("porttypename\">[A-Za-z0-9]*");
//                    Matcher matcher = pattern.matcher(responseResponseEntity);
//                    while (matcher.find()) {
//                        int count = 0;
//                        keyList.add(matcher.group(0).replace("porttypename\">",""));
//
//                    }
//                }
//
//                {
//                    Pattern pattern = Pattern.compile("http:\\/\\/[^\\s]*?.wsdl");
//                    Matcher matcher = pattern.matcher(responseResponseEntity);
//                   while (matcher.find()) {
//
//                        int count = matcher.groupCount();
//
//
//                            valueList.add(matcher.group(0));
//
//                    }
//                }
//
//                if(!CollectionUtils.isEmpty(keyList)){
//                    StringJoiner joiner = new StringJoiner(",");
//                    int i = 0;
//                    for(String key : keyList){
//                        if(i<valueList.size()) {
//                            joiner.add(key + "=" + valueList.get(i));
//                        }else{
//                            joiner.add(key+"=");
//                        }
//                        i++;
//                    }
//                    routeInfo.setUrl(joiner.toString());
//
//                }
//            }else{
//                routeInfo.setUrl(responseResponseEntity);
//            }
//
//
//        } catch (Exception e) {
//            System.out.println("Exception " + e.getLocalizedMessage());
//        }
//    }
//
//    private void getAndSetDetailsFromSwagger(String host, ModuleRouteInfo routeInfo) {
//        try {
//            String responseResponseEntity = client.getRestSwagger(host);
//
//            if (responseResponseEntity != null && !responseResponseEntity.contains("Fetch-Exception")) {
//                Swagger swagger = new Swagger20Parser().parse(responseResponseEntity);
//                StringJoiner joiner = new StringJoiner(",");
//                if(swagger != null && !CollectionUtils.isEmpty(swagger.getPaths())){
//                    for(Map.Entry<String, Path> entry : swagger.getPaths().entrySet()){
//                        if(entry.getValue().getGet() != null){
//                                joiner.add(entry.getValue().getGet().getOperationId() + "=GET:"+ entry.getKey());
//                        }else if(entry.getValue().getPost() != null){
//                            joiner.add(entry.getValue().getPost().getOperationId() + "=POST:"+ entry.getKey());
//                        }else if(entry.getValue().getPut() != null){
//                            joiner.add(entry.getValue().getPut().getOperationId() + "=PUT:"+ entry.getKey());
//
//                        }else if(entry.getValue().getDelete() != null){
//                            joiner.add(entry.getValue().getDelete().getOperationId() + "=DELETE:"+ entry.getKey());
//
//                        }
//
//                    }
//                    routeInfo.setUrl(joiner.toString());
//                }
//            }else{
//                routeInfo.setUrl(responseResponseEntity);
//            }
//
////            swagger
////            if(response != null && CollectionUtils.isEmpty(response.getPaths())){
////
////            }
//        } catch (Exception e) {
//            System.out.println("Exception " + e.getLocalizedMessage());
//        }
//    }
//
//    public void compareLastTwoVersions(int from, int to) {
//        Map<String, ModuleRouteInfo> recentVersion = new HashMap<>();
//        Map<String,ModuleRouteInfo> prevVersion = new HashMap<>();
//
//        {
//            Iterable<ModuleRouteInfo> podList = dao.findAll();
//
//            if (podList != null) {
//                for (ModuleRouteInfo pod : podList) {
//                    if (pod.getVersion() == from) {
//                        recentVersion.put(pod.getModule_Name(), pod);
//                    } else if (pod.getVersion() == to) {
//                        prevVersion.put(pod.getModule_Name(), pod);
//                    }
//                }
//            }
//        }
//
//        compare(recentVersion,prevVersion);
//
//    }
//
//    private void compare(Map<String, ModuleRouteInfo> recentVersion, Map<String, ModuleRouteInfo> prevVersion) {
//
//        for(Map.Entry<String, ModuleRouteInfo> entry: recentVersion.entrySet()){
//
//            ModuleRouteInfo stat = prevVersion.get(entry.getKey());
//            compareEndpoint(entry.getValue(),stat);
//
//        }
//
//    }
//
//    private void compareEndpoint(ModuleRouteInfo nVersion, ModuleRouteInfo pVersion) {
//        if(nVersion.getType().equals("REST")){
//            compareRestVersions(nVersion,pVersion);
//        }else{
//            compareSoapVersion(nVersion,pVersion);
//        }
//    }
//
//    private void compareSoapVersion(ModuleRouteInfo nVersion, ModuleRouteInfo pVersion) {
//
//        if(pVersion == null){
//            if (nVersion.getUrl() == null || nVersion.getUrl().contains("Fetch-Exception ")) {
//                Pod pod =podCache.getPod(nVersion.getModule_Name());
//                podCache.getSoapEndpoint().add(nVersion.getHost() + ", " + nVersion.getUrl());
//            }else{
//                Pod pod =podCache.getPod(nVersion.getModule_Name());
//                Map<String, String> keyValueMap = OcpUtil.getEnvList(nVersion.getUrl());
//                for(Map.Entry<String, String> entry : keyValueMap.entrySet()) {
//                    pod.getSoapListAdded().put(entry.getKey(),entry.getValue());
//                }
//                pod.setSoapHost(nVersion.getHost());
//            }
//        }else{
//            if (nVersion.getUrl() == null || nVersion.getUrl().contains("Fetch-Exception ")) {
//                Pod pod =podCache.getPod(nVersion.getModule_Name());
//                podCache.getSoapEndpoint().add(nVersion.getHost() + ", " + nVersion.getUrl());
//            }else{
//                Pod pod =podCache.getPod(nVersion.getModule_Name());
//                Map<String, String> nKeyValueMap = OcpUtil.getEnvList(nVersion.getUrl());
//                pod.setSoapHost(nVersion.getHost());
//                Map<String, String> oKeyValueMap = OcpUtil.getEnvList(pVersion.getUrl());
//
//                for(Map.Entry<String, String> entry : nKeyValueMap.entrySet()){
//
//                    String oValue = oKeyValueMap.get(entry.getKey());
//                    if(oValue == null){
//                        pod.getSoapListAdded().put(entry.getKey(),entry.getValue());
//                    }else if(!oValue.equals(entry.getValue())){
//                        pod.getSoapListDiff().put(entry.getKey(),entry.getValue());
//                    }
//
//                }
//
//                for(Map.Entry<String, String> entry : oKeyValueMap.entrySet()){
//
//                    String nValue = nKeyValueMap.get(entry.getKey());
//                    if(nValue == null){
//                        pod.getSoapListDeleted().put(entry.getKey(),entry.getValue());
//                    }
//
//                }
//
//            }
//        }
//    }
//
//    private void compareRestVersions(ModuleRouteInfo nVersion, ModuleRouteInfo pVersion) {
//        {
//
//            if(pVersion == null){
//                if (nVersion.getUrl() == null || nVersion.getUrl().contains("Fetch-Exception ")) {
//                    Pod pod =podCache.getPod(nVersion.getModule_Name());
//                    podCache.getRestEndpoint().add(nVersion.getHost() + ", " + nVersion.getUrl());
//                    pod.setRestAdded(true);
//                }else{
//                    Pod pod =podCache.getPod(nVersion.getModule_Name());
//                    Map<String, String> keyValueMap = OcpUtil.getEnvList(nVersion.getUrl());
//                    for(Map.Entry<String, String> entry : keyValueMap.entrySet()) {
//                        pod.getRestListAdded().put(entry.getKey(),entry.getValue());
//                    }
//                    pod.setRestHost(nVersion.getHost());
//                    pod.setRestAdded(true);
//                }
//            }else{
//                if (nVersion.getUrl() == null || nVersion.getUrl().contains("Fetch-Exception ")) {
//                    Pod pod =podCache.getPod(nVersion.getModule_Name());
//                    podCache.getRestEndpoint().add(nVersion.getHost() + ", " + nVersion.getUrl());
//                }else{
//                    Pod pod =podCache.getPod(nVersion.getModule_Name());
//                    Map<String, String> nKeyValueMap = OcpUtil.getEnvList(nVersion.getUrl());
//                    pod.setRestHost(nVersion.getHost());
//                    Map<String, String> oKeyValueMap = OcpUtil.getEnvList(pVersion.getUrl());
//
//                    for(Map.Entry<String, String> entry : nKeyValueMap.entrySet()){
//
//                        String oValue = oKeyValueMap.get(entry.getKey());
//                        if(oValue == null){
//                            pod.getRestListAdded().put(entry.getKey(),entry.getValue());
//                        }else if(!oValue.equals(entry.getValue())){
//                            pod.getRestListDiff().put(entry.getKey(),entry.getValue());
//                        }
//
//                    }
//
//                    for(Map.Entry<String, String> entry : oKeyValueMap.entrySet()){
//
//                        String nValue = nKeyValueMap.get(entry.getKey());
//                        if(nValue == null){
//                            pod.getRestListDeleted().put(entry.getKey(),entry.getValue());
//                        }
//
//                    }
//
//                }
//            }
//        }
//    }

    public void transformSwagger(String basePath, RouteListSuccessResponse responseList) throws OcpException {
                List<String> fileNameList = new LinkedList<>();
               if(responseList != null && !CollectionUtils.isEmpty(responseList.getItems())){
                   for(Item item : responseList.getItems()){
                       if(item.getMetadata().getName().contains("rest")) {
                           try {
                               String responseResponseEntity = client.getRestSwagger(item.getSpec().getHost());
                               if (responseResponseEntity != null && !responseResponseEntity.contains("Fetch-Exception")) {
                                   Swagger swagger = new Swagger20Parser().parse(responseResponseEntity);
                                   if (swagger == null) {
                                       continue;
                                   }
                                   Info info = swagger.getInfo();
                                   String xIbmName = null;
                                   String version ="1.0.0";
                                   if (info != null) {
                                       String origTitle = info.getTitle();
                                        xIbmName = origTitle.toLowerCase().replaceAll(" ", "-");
                                       info.getVendorExtensions().put("x-ibm-name", xIbmName);
                                       info.setVersion(version);
                                   }
                                   swagger.setHost("$(catalog.host)");
                                   List<Scheme> schemeList = new ArrayList<>();
                                   schemeList.add(Scheme.HTTPS);
                                   swagger.setSchemes(schemeList);
                                   swagger.setBasePath("/fuse");

                                   ApiKeyAuthDefinition clientSecretSDF = new ApiKeyAuthDefinition();
                                   clientSecretSDF.setName("X-IBM-Client-Secret");
                                   clientSecretSDF.setIn(In.HEADER);
                                   swagger.addSecurityDefinition("clientSecretHeader", clientSecretSDF);

                                   ApiKeyAuthDefinition clientIdSDF = new ApiKeyAuthDefinition();
                                   clientIdSDF.setName("X-IBM-Client-Id");
                                   clientIdSDF.setIn(In.HEADER);
                                   swagger.addSecurityDefinition("clientIdHeader", clientIdSDF);


                                   SecurityRequirement clientIdSR = new SecurityRequirement();
                                   clientIdSR.setRequirements("clientIdHeader",new ArrayList<>());
                                   clientIdSR.setRequirements("clientSecretHeader",new ArrayList<>());
//                                   SecurityRequirement clientSecretSR = new SecurityRequirement();
//                                   clientSecretSR.setRequirements("clientSecretHeader",new ArrayList<>());
                                   swagger.addSecurity(clientIdSR);
//                                   swagger.addSecurity(clientSecretSR);

                                   XIbmConfiguration xIbmConfiguration = new XIbmConfiguration();
                                   xIbmConfiguration.setTestable(true);
                                   xIbmConfiguration.setEnforced(true);
                                   Cors cors = new Cors();
                                   cors.setEnabled(true);
                                   xIbmConfiguration.setCors(cors);
                                   Assembly assembly = new Assembly();
                                   assembly.setExecute(new LinkedList<>());
                                   Execute activityLog = new Execute();
                                   ActivityLog alog = new ActivityLog();
                                   alog.setContent("activity");
                                   alog.setErrorContent("payload");
                                   alog.setTitle("activity-log");
                                   alog.setVersion("1.0.0");
                                   activityLog.setActivityLog(alog);
                                   assembly.getExecute().add(activityLog);

                                   Execute invoke = new Execute();
                                   Invoke invk = new Invoke();
                                   invk.setTargetUrl("$(fuse-endpoint)$(api.operation.path)$(request.search)");
                                   invoke.setInvoke(invk);
                                   assembly.getExecute().add(invoke);

                                   xIbmConfiguration.setAssembly(assembly);

                                   xIbmConfiguration.setPhase("realized");
                                   Properties properties = new Properties();
                                   FuseEndpoint fuseEndPoint = new FuseEndpoint();
                                   fuseEndPoint.setDescription("");
                                   fuseEndPoint.setValue("");
                                   fuseEndPoint.setEncoded(false);
                                   properties.setFuseEndpoint(fuseEndPoint);
                                   xIbmConfiguration.setProperties(properties);


                                   Catalogs catalogs = new Catalogs();
                                   Staging staging = new Staging();
                                   Properties_ prop = new Properties_();
                                   prop.setFuseEndpoint("http://" + item.getSpec().getHost());
                                   staging.setProperties(prop);

                                   Development dev = new Development();
                                   dev.setProperties(prop);
                                   catalogs.setStaging(staging);
                                   catalogs.setDevelopment(dev);
                                   xIbmConfiguration.setCatalogs(catalogs);
                                   swagger.setVendorExtension("x-ibm-configuration", xIbmConfiguration);

                                   Map<String, Path> pathMap = swagger.getPaths();
                                   for(Map.Entry<String, Path> entry : pathMap.entrySet()){
                                       Path path = entry.getValue();
                                       List<Operation> operationList = path.getOperations();
                                       for(Operation operation : operationList){
                                           Map<String, Response> responseMap = operation.getResponses();
                                           if(responseMap != null){
                                               for( Map.Entry<String, Response> respEntry : responseMap.entrySet()){
                                                   if(respEntry != null && respEntry.getValue() != null){
                                                       Response response = respEntry.getValue();
                                                       if(response.getExamples() != null){
                                                           Map<String, Object> examples = response.getExamples();
                                                           List<String> remExamples = new LinkedList<>();
                                                           for(Map.Entry<String, Object> egEntry : examples.entrySet()){
                                                               System.out.println(" Type : " +egEntry.getValue().getClass() + " value : " + egEntry.getValue());
                                                               if(egEntry.getValue() != null && egEntry.getValue() instanceof  String){
                                                                    String actualValue = (String) egEntry.getValue();
                                                                    if(StringUtils.isEmpty(actualValue)){
                                                                        remExamples.add(egEntry.getKey());
                                                                    }
                                                               }
                                                           }
                                                           for(String remKey : remExamples){
                                                               examples.remove(remKey);
                                                           }
                                                       }
                                                   }
                                               }
                                           }
                                       }
                                   }


                                   System.out.println(item.getSpec().getHost());
                                   File nFile = new File("api/"+xIbmName+"_"+version+".yaml") ;
                                   String prettyYaml=Yaml.pretty().writeValueAsString(swagger).replace("---\n","");
                                   FileUtils.write(nFile,prettyYaml);
                                   fileNameList.add(nFile.getName());


                               }
                           } catch (OcpException | IOException e) {
                               e.printStackTrace();
                               System.err.println("Exception Occurred :: " + e);
                           }
                       }

                   }
                }


        }
}
