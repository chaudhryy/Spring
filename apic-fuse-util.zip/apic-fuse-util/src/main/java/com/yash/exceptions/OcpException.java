package com.yash.exceptions;

public class OcpException  extends  Exception{

    public OcpException(String message){
        super(message);
    }

}
