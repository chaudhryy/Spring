//
//package nz.co.spark.openshift.utility.reg.model;
//
//import com.fasterxml.jackson.annotation.JsonInclude;
//import com.fasterxml.jackson.annotation.JsonProperty;
//import com.fasterxml.jackson.annotation.JsonPropertyOrder;
//
//@JsonInclude(JsonInclude.Include.NON_NULL)
//@JsonPropertyOrder({
//    "fuse-endpoint"
//})
//public class Properties {
//
//    @JsonProperty("fuse-endpoint")
//    private FuseEndpoint fuseEndpoint;
//
//    @JsonProperty("fuse-endpoint")
//    public FuseEndpoint getFuseEndpoint() {
//        return fuseEndpoint;
//    }
//
//    @JsonProperty("fuse-endpoint")
//    public void setFuseEndpoint(FuseEndpoint fuseEndpoint) {
//        this.fuseEndpoint = fuseEndpoint;
//    }
//
//    public Properties withFuseEndpoint(FuseEndpoint fuseEndpoint) {
//        this.fuseEndpoint = fuseEndpoint;
//        return this;
//    }
//
//}
