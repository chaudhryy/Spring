package nz.co.spark.openshift.utility.reg.exceptions;

public class OcpException  extends  Exception{

    public OcpException(String message){
        super(message);
    }

}
