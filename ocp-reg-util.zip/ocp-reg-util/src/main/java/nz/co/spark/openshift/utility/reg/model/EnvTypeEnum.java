package nz.co.spark.openshift.utility.reg.model;

public enum EnvTypeEnum {
    PROD,
    NPE,
    REG;
}
