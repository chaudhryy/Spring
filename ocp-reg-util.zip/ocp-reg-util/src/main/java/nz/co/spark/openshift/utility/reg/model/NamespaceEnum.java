package nz.co.spark.openshift.utility.reg.model;

public enum NamespaceEnum {

}
