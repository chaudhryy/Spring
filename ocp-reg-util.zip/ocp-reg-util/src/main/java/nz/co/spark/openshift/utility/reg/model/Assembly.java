//
//package nz.co.spark.openshift.utility.reg.model;
//
//import java.util.List;
//import com.fasterxml.jackson.annotation.JsonInclude;
//import com.fasterxml.jackson.annotation.JsonProperty;
//import com.fasterxml.jackson.annotation.JsonPropertyOrder;
//
//@JsonInclude(JsonInclude.Include.NON_NULL)
//@JsonPropertyOrder({
//    "execute"
//})
//public class Assembly {
//
//    @JsonProperty("execute")
//    private List<Execute> execute = null;
//
//    @JsonProperty("execute")
//    public List<Execute> getExecute() {
//        return execute;
//    }
//
//    @JsonProperty("execute")
//    public void setExecute(List<Execute> execute) {
//        this.execute = execute;
//    }
//
//    public Assembly withExecute(List<Execute> execute) {
//        this.execute = execute;
//        return this;
//    }
//
//}
