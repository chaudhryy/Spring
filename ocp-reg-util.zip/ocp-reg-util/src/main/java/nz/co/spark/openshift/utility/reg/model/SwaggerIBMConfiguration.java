//
//package nz.co.spark.openshift.utility.reg.model;
//
//import com.fasterxml.jackson.annotation.JsonInclude;
//import com.fasterxml.jackson.annotation.JsonProperty;
//import com.fasterxml.jackson.annotation.JsonPropertyOrder;
//
//@JsonInclude(JsonInclude.Include.NON_NULL)
//@JsonPropertyOrder({
//    "x-ibm-configuration"
//})
//public class SwaggerIBMConfiguration {
//
//    @JsonProperty("x-ibm-configuration")
//    private XIbmConfiguration xIbmConfiguration;
//
//    @JsonProperty("x-ibm-configuration")
//    public XIbmConfiguration getXIbmConfiguration() {
//        return xIbmConfiguration;
//    }
//
//    @JsonProperty("x-ibm-configuration")
//    public void setXIbmConfiguration(XIbmConfiguration xIbmConfiguration) {
//        this.xIbmConfiguration = xIbmConfiguration;
//    }
//
//    public SwaggerIBMConfiguration withXIbmConfiguration(XIbmConfiguration xIbmConfiguration) {
//        this.xIbmConfiguration = xIbmConfiguration;
//        return this;
//    }
//
//}
