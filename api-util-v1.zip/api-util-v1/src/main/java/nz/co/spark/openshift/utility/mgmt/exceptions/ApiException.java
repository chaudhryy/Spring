package nz.co.spark.openshift.utility.mgmt.exceptions;

public class ApiException extends  Exception{

    public ApiException(String message){
        super(message);
    }

}
