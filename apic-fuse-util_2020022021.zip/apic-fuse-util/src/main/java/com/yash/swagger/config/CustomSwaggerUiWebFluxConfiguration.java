//package com.yash.swagger.config;
//
//import springfox.boot.starter.autoconfigure.SwaggerUiWebFluxConfiguration;
//
//public class CustomSwaggerUiWebFluxConfiguration extends SwaggerUiWebFluxConfiguration {
//}
